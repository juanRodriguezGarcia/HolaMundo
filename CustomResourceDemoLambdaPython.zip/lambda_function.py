import logging
logger = logging.getLogger()
logger.setLevel("INFO")

from crhelper import CfnResource
 
helper = CfnResource()

@helper.create
@helper.update
def sum_2_numbers(event, _):
    s = int(event['ResourceProperties']['No1']) + int(event['ResourceProperties']['No2'])
    r = int(event['ResourceProperties']['No1']) - int(event['ResourceProperties']['No2'])
    helper.Data['Sum'] = s
    helper.Data['Restamos'] = r 
@helper.delete
def no_op(_, __):
    pass

def handler(event, context):
    logger.debug("debug xyz")
    logger.info("working as expected")
    logger.warning("disk space low")
    logger.error("carousel not performing")
    logger.critical("login function unresponsive") 
    logger.critical("########################################### ... EVENTO ... ################################################") 
    logger.info(event)
    helper(event, context)
    
#import json

#def lambda_handler(event, context):
#    # TODO implement
#    return {
#        'statusCode': 200,
#        'body': json.dumps('Hello from Lambda!')
#    }
