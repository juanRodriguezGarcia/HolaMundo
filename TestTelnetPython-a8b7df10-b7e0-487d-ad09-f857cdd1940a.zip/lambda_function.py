import json
import boto3
import base64
import socket

IP = 'translate.google.com'
PORT = 83


def lambda_handler(event, context):
    # TODO implement
    #print(event)

    IP = event['host']
    PORT = event['port']

    print(':::::::::::::___IP-HOST_::::::::::::::::_:' + IP )
    print(':::::::::::::___PUERTO__::::::::::::::::::' + PORT )
    sock= socket.socket(socket.AF_INET,socket.SOCK_STREAM)
    result = sock.connect_ex((IP,int(event['port'])))
    if result == 0:
        print(f'Port {PORT} is open on {IP}')
    else:
        print(f'Port {PORT} is closed on {IP}')
        
        
     
    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }
